<?if (!defined('CURR_VER')) {
    require_once "{$_SERVER['DOCUMENT_ROOT']}/index.php";
}