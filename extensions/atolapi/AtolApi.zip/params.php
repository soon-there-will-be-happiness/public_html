<?php

// Создание папок
// здесь перечисляем список папок которые должны создаться при установке
// расширения
$folders = array(
    array('/extensions/atolapi'),
    array('/extensions/atolapi/config'),
    array('/extensions/atolapi/controllers'),
    array('/extensions/atolapi/models'),
    array('/extensions/atolapi/views'),
);


// Перемещение файлов имя => куда
$files = array(
    array('/atolapi/config/routes.php', 'extensions/atolapi/config/routes.php'),
	array('/atolapi/controllers/adminAtolapiController.php', 'extensions/atolapi/controllers/adminAtolapiController.php'),
	array('/atolapi/controllers/atolapiController.php', 'extensions/atolapi/controllers/atolapiController.php'),
	array('/atolapi/models/atolapi.php', 'extensions/atolapi/models/atolapi.php'),
    array('/atolapi/models/Client.php', 'extensions/atolapi/models/Client.php'),
    array('/atolapi/models/Company.php', 'extensions/atolapi/models/Company.php'),
    array('/atolapi/models/Item.php', 'extensions/atolapi/models/Item.php'),
    array('/atolapi/models/Items.php', 'extensions/atolapi/models/Items.php'),
    array('/atolapi/models/Receipt.php', 'extensions/atolapi/models/Receipt.php'),
	array('/atolapi/views/settings.php', 'extensions/atolapi/views/settings.php'),
    array('/atolapi.svg', 'template/admin/images/ext/atolapi.svg'),
);

// Для установки в БД
$name = 'atolapi'; // Здесь
$file_name = 'atolapi';
$title = 'Atol API';
$type = 'system';
$version = '1.0';
$enable = 0;
$link = 'atolapi-settings';
$params = '';
?>